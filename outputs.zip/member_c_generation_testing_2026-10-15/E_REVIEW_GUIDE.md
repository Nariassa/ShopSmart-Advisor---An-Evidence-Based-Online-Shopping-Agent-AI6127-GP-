# 给系统集成、交互与综合评估模块 的评分说明

本包包含固定候选池上的开发生成结果，不是独立正式评估结果。先阅读 summary.md 及 manifest.json。候选展示顺序不是已确认的检索排名，人工检索标签没有作为模型输入。

## 推荐操作

1. 将 blinded_review_answers.md 或 blinded_review_packets.jsonl 提供给标注者。model_key_for_E.csv 由 系统集成、交互与综合评估模块 单独保存，评分前不向标注者公开。匿名顺序不能保证彻底消除文风识别等偏差。
2. 每位标注者分别复制 human_review_template.csv 与 claim_support_review_template.csv，填 reviewer_id；独立评分后再计算 IAA。当前模板没有填任何评分，不能声称已完成人评或 IAA。
3. 在知道模型前先完成评分和分歧记录；需要仲裁时保留原始标签。
4. ragas_inputs.jsonl 提供实际模型事实上下文与最终回答；没有 reference 的记录不能计算必须有参考答案的指标。model、query_id、evaluation_id 是配对字段，使用 RAGAS 时按其版本映射必需列。

## 回答级建议评分

| 维度 | 1 分 | 3 分 | 5 分 |
| --- | --- | --- | --- |
| relevance | 商品或内容明显偏离需求 | 部分满足，夹杂无关内容 | 直接回应主要需求，商品类型匹配 |
| faithfulness | 存在重要不支持或矛盾结论 | 大体支持，有限定条件缺失 | 各结论均有充分支持且不扩大范围 |
| completeness | 遗漏主要需求或重要限制 | 覆盖部分方面 | 覆盖主要需求，缺证据处有明确说明 |
| balance | 丢失重要相反证据或误导分歧 | 有正反信息但不充分 | 如实反映同商品同方面的相关分歧 |
| english_clarity | 难以理解或明显语言错误 | 可读但重复或表达生硬 | 清晰简洁，范围和归属明确 |

无相关正反证据可供判断时，balance 填 NA，而不是强行给满分。正确拒答应根据证据是否足够判断，不因拒答直接判低分或高分。

## 逐结论建议标签

support_label 可填写 supported、partially_supported、unsupported、contradicted 或 unclear，并在 reason 写明遗漏的否定、时间、数量、产品归属或范围条件。NLI 通过不代表该结论必然正确；请对照原文独立判断。

检查时尤其注意：蓝牙功能存在不等于稳定连接；通用正面评价不等于满足具体方面；同类配件不等于目标商品；一个人的体验不能自动推广到全部用户。

## 自动线索不是评分

automatic_review_flags.csv 标记了方面标签遗漏、情感词典下的反对证据遗漏、改写被拒绝后原文保留、名称/ID 拒绝等。标注者可在独立评分后查看这些线索，避免被自动结论锚定。

PCS 和情感适配分数仍是实验指标。高 PCS 不能解释为高购买满意概率；持续负面体验也可能高度一致。
