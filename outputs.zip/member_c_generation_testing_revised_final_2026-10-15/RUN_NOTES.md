# 最终修复重测运行说明

日期：2026-10-15。旧基线目录 member_c_generation_testing_2026-10-15 完整保留。最终修复使用相同问题、原始候选、顺序、解码参数、权重 digest 和 PCS 时间，另建本目录保存结果。

早期诊断批次 member_c_generation_testing_revised_2026-10-15 在发现归属语引发 NLI 误拒绝后主动停止，其输出和代码快照保留并标记 DIAGNOSTIC_ONLY。最终批次从头运行，不混用该诊断批次的逐题记录。

本批 generation_revision=bounded_type_scope_display_v3_attribution_aware_nli。代码与输入冻结后未在批次中途修改。模型按顺序执行，每个模型全部问题完成后释放内存权重；原有 Ollama 服务及本地下载权重保留。

耗时包含本地模型加载和推理，非严格硬件性能基准。联合修复会改变实际事实上下文及商品，不是单独 Prompt 消融。人工评分与正式评估仍未执行。
