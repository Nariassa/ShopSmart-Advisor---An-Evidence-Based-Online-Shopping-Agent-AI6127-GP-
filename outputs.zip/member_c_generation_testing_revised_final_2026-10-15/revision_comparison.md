# 四项修复后的配对重测

同一批 20 个问题、791 条原始候选、候选顺序、模型权重、解码参数和 PCS 时间。商品过滤、选择提示、Schema、改写守卫和显示层共同变化，因此是整条生成流程的修复回归，不是单独 Prompt 效果消融。过滤会改变实际给模型的事实和最终商品，详见 revision_pairs.csv。

| 模型 | 成功生成（前→后） | 名称拒绝（前→后） | HTML 残片回答（前→后） | 改写通过（前→后） | 新增守卫拒绝 |
| --- | --- | --- | --- | --- | --- |
| qwen2.5:7b | 20/20 → 20/20 | 2 → 0 | 7 → 0 | 86 → 44 | 45 |
| llama3.1:8b | 18/20 → 20/20 | 0 → 0 | 6 → 0 | 85 → 46 | 69 |

## 修复验证

- same_raw_candidates: True
- all_40_attempts_present: True
- same_queries: True
- same_pcs_time: True
- same_model_weights: True
- all_raw_evidence_pairs_equal: True
- common_product_pcs_unchanged: True
- all_call_limits_equal_8: True
- excluded_products_never_reinserted: True
- all_final_review_rewrites_attributed: True
- one_final_conclusion_per_fact: True

## 解读与限制

- 新增守卫拒绝不等于发现同等数量的幻觉：守卫刻意保守，可能拒绝语义正确的省略或同义替换；被拒绝时保留原句及来源。
- 名称只归一化 HTML 实体、Unicode NFC 和空白，保留所有词语、型号和后缀，不接受缩略名称。
- 商品类型通过查询和标题规则判断，未训练分类器。未知类型不自动声称已验证，保守规则可能误排合法商品或漏掉不匹配品。功能、兼容性、耐久性等需要原文支持及人工复核。
- 个人归属、数字、显式否定和条件检查是必要条件启发式，不构成完整逻辑等价判断。NLI 阈值仍为 0.9，未通过提高阈值替代这些检查。
- 方面标签遗漏线索可能增加；这不是语义覆盖率。请结合商品集合变化和实际原文做独立人评，不把所有维度解释为同步改善。
- 存在已保存残留反例：Qwen Q004/F1 保留否定词和 unless，但弱化 not as good as SP3 的比较含义，NLI 仍通过。详见 QUALITY_REVIEW.md。
- 显示层去除 HTML，结构化 claim.text、citation.quote、sources.text 和 start/end 保持原文。
- 仍用未校准情感词典和方面标签；讽刺情感错误、方面覆盖低估、PCS 校准与 方面分析与购买决策解释模块 的正式接口本次未处理。
- 缺少 检索与排序评估模块 的正式检索排名、独立测试集及人工语义评分；不能将成功率或引用核验率解释为回答准确率。
