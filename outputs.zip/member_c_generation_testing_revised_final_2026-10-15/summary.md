# Grounded Generation & Purchase Confidence Scoring Generation Testing

本批为固定标注候选池回放的开发生成测试，不是新检索排名或独立正式评估。

计划 40 次；已记录 40 次；产生真实模型回答 40 次。
来源及原文位置核验：233/233。此比例不代表语义正确率。

| 模型 | 生成回答 | 选择通过 | 选择拒绝 | 改写通过 | NLI 拒绝改写 | 引用核验 | 平均耗时 |
| --- | ---: | ---: | ---: | ---: | ---: | --- | ---: |
| qwen2.5:7b | 20 | 90 | 0 | 44 | 9 | 109/109 | 13.87s |
| llama3.1:8b | 20 | 117 | 2 | 46 | 9 | 124/124 | 15.87s |

## 已完成与待 系统集成、交互与综合评估模块 完成

- 已完成：同问题同证据生成、英文单事实改写、NLI 核验、引用核验、逐题运行记录和盲评材料。
- 待系统集成、交互与综合评估模块：人工相关性、支持性、完整性、平衡及表达评分；IAA；适用的 RAGAS 指标计算。模板留空，不伪造人评分数。
- 自动方面覆盖和正反保留检查使用方面标签及未校准情感词典，只是待复核线索。

## 运行范围

全部 791 条候选按原 display_order 回放，原文从 Parquet 回填并逐条核对 SHA-256。
没有使用 relevance_label、confidence 或 reason 选择/重排证据，也没有把这些标注送入模型。
候选池的原始检索混合方法和排序未知，display_order 只表示标注展示顺序，不能当作 检索与排序评估模块 的检索排名。
没有 reference 的问题不添加参考答案。RAGAS 输入的 contexts 为实际发给选择模型的事实句，完整候选原文另行保留。
模型参数、证据顺序、选择 Prompt 和 PCS 时间固定；模型后续选择与改写可能不同。
性能统计包含每模型首次冷加载和后续常驻调用，不是正式系统吞吐量基准。
有错误会保留逐题失败记录；程序补入的证据与模型选择分开计数。

## 自动复核线索

- missing_requested_aspect_tags_proxy: 24 个回答
- rewrite_rejected_original_retained: 13 个回答
- rewrite_safety_guard_original_retained: 28 个回答
- selection_proposals_rejected: 1 个回答
